# Taxue增强模式指南

## 一、核心理念

**无侵入性设计**：
- ✅ 只读取SKILL.md，不修改任何技能文件
- ✅ 缓存文件放在用户目录（`~/.skill-adapter-cache.json`）
- ✅ 技能目录完全不受影响
- ✅ 卸载后无残留

## 二、工作原理

### 传统模式 vs 增强模式

| 维度 | 传统模式 | 增强模式 |
|------|---------|---------|
| **技能发现** | 手动记忆技能名 | 自动扫描SKILL.md |
| **路由方式** | 硬编码路由表 | 动态查询适配器 |
| **扩展性** | 新增技能需修改配置 | 新增技能自动被发现 |
| **专业性** | 通用技能优先 | 专业技能优先 |
| **侵入性** | 可能修改技能文件 | **完全只读** |

### 工作流程

```
用户问题 → taxue识别领域 → 查询适配器 → 有专业技能？ → 调用专业技能
                                    ↓
                              无专业技能 → 使用taxue子技能
```

**关键点**：适配器只读取SKILL.md，不写入任何文件到技能目录。

## 三、安装与设置

### 一键设置（推荐）

```bash
# 运行设置脚本
bash ~/.agents/skills/taxue/scripts/setup-adapter.sh
```

设置脚本会：
1. 扫描所有技能目录的SKILL.md
2. 提取技能信息到内存
3. 生成缓存文件（`~/.skill-adapter-cache.json`）
4. 测试适配器和taxue桥接

**不会做的事**：
- ❌ 不在技能目录创建interface.json
- ❌ 不修改任何SKILL.md文件
- ❌ 不影响任何外部技能

### 手动设置

```bash
# 生成缓存
python3 ~/.agents/skills/skill-orchestrator/scripts/skill-adapter.py list

# 测试
python3 ~/.agents/skills/taxue/scripts/taxue-adapter-bridge.py "投资"
```

## 四、使用方式

### 方式1：自动使用（推荐）

直接使用taxue，它会自动查询适配器：
```
用户：分析茅台股票
taxue：识别为投资问题 → 查询适配器 → 发现invest-stock → 调用专业技能
```

### 方式2：命令行测试

```bash
# 搜索相关技能
python3 ~/.agents/skills/skill-orchestrator/scripts/skill-adapter.py search "投资"

# 测试taxue桥接
python3 ~/.agents/skills/taxue/scripts/taxue-adapter-bridge.py "如何投资基金"

# 列出所有技能
python3 ~/.agents/skills/skill-orchestrator/scripts/skill-adapter.py list
```

## 五、效果对比

### 示例1：投资分析

**传统模式**：
```
用户：分析茅台股票
taxue：识别为投资问题 → 路由到taxue-business → 通用商业分析
```

**增强模式**：
```
用户：分析茅台股票
taxue：查询适配器 → 发现invest-stock（置信度15）→ 调用专业技能
invest-stock：三关审查、四维评分、机构深度分析
```

**效果提升**：
- 专业性：通用商业分析 → 专业股票分析
- 深度：表面建议 → 结构化审查
- 可操作性：模糊方向 → 具体步骤

### 示例2：准备面试

**传统模式**：
```
用户：准备面试
taxue：识别为职业问题 → 路由到taxue-career → 通用职业建议
```

**增强模式**：
```
用户：准备面试
taxue：查询适配器 → 发现interview-coach（置信度12）→ 调用专业技能
interview-coach：技术面模拟、行为面练习、系统设计演练
```

## 六、分享给其他人

### 分享步骤

1. **打包技能目录**
   ```bash
   tar -czf taxue-enhanced.tar.gz ~/.agents/skills/skill-orchestrator ~/.agents/skills/taxue
   ```

2. **对方安装**
   ```bash
   tar -xzf taxue-enhanced.tar.gz -C ~/.agents/skills/
   bash ~/.agents/skills/taxue/scripts/setup-adapter.sh
   ```

3. **完成**
   - 对方自动获得所有技能的调用能力
   - 无需手动配置，安装即用
   - **不影响对方已有的任何技能**

### 分享优势

- **零配置**：对方只需运行设置脚本
- **自动发现**：自动扫描对方已安装的所有技能
- **无侵入性**：不修改对方的任何技能文件
- **持续更新**：对方安装新技能后，重新运行设置脚本即可

## 七、更新与维护

### 更新技能后

当安装新技能后，重新运行设置脚本：
```bash
bash ~/.agents/skills/taxue/scripts/setup-adapter.sh
```

### 清除缓存

如果需要重新扫描所有技能：
```bash
rm -f ~/.skill-adapter-cache.json
python3 ~/.agents/skills/skill-orchestrator/scripts/skill-adapter.py list
```

### 调试模式

```bash
# 查看详细日志
python3 ~/.agents/skills/taxue/scripts/taxue-adapter-bridge.py "问题" 2>&1 | grep -E "(读取技能|搜索|匹配)"
```

## 八、技术细节

### 只读模式

- **数据来源**：只读取SKILL.md文件
- **缓存位置**：`~/.skill-adapter-cache.json`（用户目录）
- **技能目录**：完全不受影响，不创建任何文件
- **卸载清理**：删除skill-orchestrator和taxue目录即可，无残留

### 缓存机制

- **缓存文件**：`~/.skill-adapter-cache.json`
- **缓存内容**：所有技能的接口信息
- **更新时机**：运行设置脚本时自动更新
- **加载方式**：优先从缓存加载，缓存不存在则扫描

### 搜索算法

当前使用关键词匹配：
1. **触发词匹配**：权重10
2. **关键词匹配**：权重5
3. **描述匹配**：权重3

未来可优化为语义匹配（embedding）。

## 九、常见问题

### Q1: 会影响我已有的技能吗？

A: **不会**。适配器只读取SKILL.md，不修改任何技能文件。缓存文件在用户目录（`~/.skill-adapter-cache.json`），不在技能目录。

### Q2: 安装新技能后需要做什么？

A: 重新运行设置脚本即可：
```bash
bash ~/.agents/skills/taxue/scripts/setup-adapter.sh
```

### Q3: 如何卸载？

A: 删除相关目录即可：
```bash
rm -rf ~/.agents/skills/skill-orchestrator
rm -rf ~/.agents/skills/taxue
rm -f ~/.skill-adapter-cache.json
```

### Q4: 性能如何？

A: 缓存机制已优化：
- 首次运行：扫描所有技能（~10秒）
- 后续运行：从缓存加载（~0.1秒）
- 缓存更新：仅在运行设置脚本时

## 十、总结

**无侵入性设计的核心优势**：

1. ✅ **只读模式**：不修改任何技能文件
2. ✅ **自动发现**：扫描所有已安装技能
3. ✅ **智能匹配**：根据问题自动选择最合适的技能
4. ✅ **易于分享**：安装即用，不影响已有技能
5. ✅ **易于卸载**：删除目录即可，无残留

**关键洞察**：
- taxue变成智能路由器，而不是硬编码路由器
- 技能自描述，通过SKILL.md声明能力
- 动态发现，新增技能自动被发现
- 无侵入性，对用户完全透明

**下一步行动**：
1. 运行设置脚本：`bash ~/.agents/skills/taxue/scripts/setup-adapter.sh`
2. 测试效果：尝试几个专业领域的问题
3. 分享给其他人：让他们也获得增强模式