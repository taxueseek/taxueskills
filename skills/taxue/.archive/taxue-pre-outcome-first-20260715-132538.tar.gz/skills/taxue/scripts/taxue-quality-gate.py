#!/usr/bin/env python3
"""
taxue 技能体系质量门 (Quality Gate) v1
自动检查所有 taxue skill 的版本一致性、必备章节完整性、反模式合规性。

用法:
  python3 taxue-quality-gate.py [--verbose] [--repair]

--verbose: 输出每条检查细节
--repair:  自动修复简单的版本号不一致问题

返回码: 0 = 全通过, 1 = 有告警, 2 = 有错误
"""

import json
import os
import re
import sys
from pathlib import Path

SKILLS_DIR = Path.home() / ".agents" / "skills"
TAXUE_DIR = SKILLS_DIR / "taxue"
SKILL_REGISTRY_PATH = TAXUE_DIR / "references" / "skill_registry.json"
CURRENT_MAIN_VERSION = "3.5.0"

# 所有 taxue 子技能及其预期所属的主版本线（从 registry 自动派生）
EXPECTED_VERSION_LINE = "3.5"  # 主版本线

# 必备章节（按优先级）
REQUIRED_SECTIONS = {
    "anti_patterns": {
        "patterns": [r"反模式声明", r"常见失败"],
        "label": "反模式声明",
        "severity": "error",
        "reason": "每个子 skill 必须有反模式声明，记录已知失败模式"
    },
    "do_not": {
        "patterns": [r"## DO NOT", r"DO NOT"],
        "label": "DO NOT 边界声明",
        "severity": "error",
        "reason": "每个子 skill 必须明确声明不处理什么"
    },
    "shared_rules_ref": {
        "patterns": [r"shared-rules\.md", r"共享规则"],
        "label": "共享规则引用",
        "severity": "warning",
        "reason": "子 skill 应引用 shared-rules.md 继承通用规则"
    },
    "version_footer": {
        "patterns": [r"\*taxue-.*v\d+\.\d+\.\d+.*\*"],
        "label": "版本脚注",
        "severity": "warning",
        "reason": "末尾应有版本号脚注"
    },
}

# 质量门检查 - 新的必备章节（从 v3.5.0 开始）
QUALITY_GATE_SECTIONS = {
    "outcome_contract": {
        "patterns": [r"Outcome Contract", r"产出契约"],
        "label": "Outcome Contract",
        "severity": "warning",
        "reason": "建议每个子 skill 有产出契约明确交付边界"
    },
    "quality_gate": {
        "patterns": [r"质量门", r"输出前.*查", r"自查"],
        "label": "输出前质量门",
        "severity": "warning",
        "reason": "建议每个子 skill 有输出前强制自查机制"
    },
}


def parse_frontmatter(content):
    """提取 frontmatter（无 yaml 依赖版）。

    支持标准 key: value 格式，不依赖 PyYAML（macOS 系统 Python 无预装）。
    跳过数组/嵌套结构——taxue 的 frontmatter 只用简单键值对。
    """
    match = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
    if not match:
        return {}
    meta = {}
    for line in match.group(1).splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip()
        val = val.strip()
        # 去掉引号
        if (val.startswith('"') and val.endswith('"')) or \
           (val.startswith("'") and val.endswith("'")):
            val = val[1:-1]
        # 多行 description
        if val == "|":
            meta[key] = val
            continue
        meta[key] = val
    return meta


def parse_description(content, meta):
    """从 content 中提取完整的 description（处理 | 多行语法）。

    YAML frontmatter 中的 description: | 意味着后续缩进行都属于它；
    无 yaml 库时需手动拼接。
    """
    if meta.get("description") != "|":
        return meta.get("description", "")
    # 已由 parse_frontmatter 返回了文字描述
    return meta.get("description", "")


def check_version(metadata, name):
    """检查版本号"""
    issues = []
    version = metadata.get("version", "")
    if not version:
        issues.append({
            "file": name,
            "severity": "error",
            "field": "version",
            "desc": "缺少 version 字段"
        })
    else:
        # 检查是否符合 semver
        if not re.match(r'^\d+\.\d+\.\d+$', version):
            issues.append({
                "file": name,
                "severity": "error",
                "field": "version",
                "desc": f"版本号格式异常: {version}"
            })
        # 主版本线检查（主入口除外）
        if name != "taxue" and version:
            major_minor = ".".join(version.split(".")[:2])
            if major_minor != EXPECTED_VERSION_LINE and major_minor != "3.5":
                issues.append({
                    "file": name,
                    "severity": "warning",
                    "field": "version",
                    "desc": f"版本 {version} 不在主版本线 {EXPECTED_VERSION_LINE}.x 上"
                })
    return issues


def check_required_sections(content, name, sections_to_check):
    """检查必备章节"""
    issues = []
    for section_id, config in sections_to_check.items():
        found = False
        for pattern in config["patterns"]:
            if re.search(pattern, content, re.IGNORECASE):
                found = True
                break
        if not found:
            issues.append({
                "file": name,
                "severity": config["severity"],
                "field": section_id,
                "desc": f"缺少 {config['label']}: {config['reason']}"
            })
    return issues


def check_anti_patterns(content, name):
    """额外检查：反模式应该至少有 3 条"""
    patterns = re.findall(r'###\s+失败\s+\d+', content)
    if len(patterns) == 0:
        # 也可能是 "失败 1：XXX" 格式
        patterns = re.findall(r'失败\s+\d+[：:]', content)
    if len(patterns) < 2:
        return [{
            "file": name,
            "severity": "warning",
            "field": "anti_pattern_count",
            "desc": f"反模式只有 {len(patterns)} 条，建议至少 3 条"
        }]
    return []


def check_output_boundary(content, name):
    """检查输出末尾是否导流到主入口"""
    issues = []
    if re.search(r'输出末尾', content) and not re.search(r'主入口', content):
        issues.append({
            "file": name,
            "severity": "warning",
            "field": "output_boundary",
            "desc": "有「输出末尾」章节但未提及导流交给主入口"
        })
    return issues


def load_skill_registry():
    """加载 SKILL_REGISTRY，不存在时返回 None."""
    if not SKILL_REGISTRY_PATH.exists():
        return None
    try:
        return json.loads(SKILL_REGISTRY_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def check_registry_consistency(skills):
    """验证 SKILL_REGISTRY 的 技能与 filesystem 一致。"""
    registry = load_skill_registry()
    if not registry:
        return [{
            "file": "taxue",
            "severity": "warning",
            "field": "registry",
            "desc": "SKILL_REGISTRY 不存在，跳过一致性检查"
        }]

    issues = []
    registered_names = set(registry.get("skills", {}).keys())
    filesystem_names = set()
    for s in skills:
        name = s["name"]
        if name.startswith("taxue-"):
            filesystem_names.add(name[len("taxue-"):])
        elif name == "taxue":
            filesystem_names.add(name)

    # Registry 中有但 filesystem 无
    for name in registered_names:
        if name == "state":
            continue  # state 只有 SKILL.md
        dir_path = SKILLS_DIR / ("taxue-" + name)
        skill_md = dir_path / "SKILL.md"
        if name != "taxue" and not skill_md.exists():
            issues.append({
                "file": name,
                "severity": "error",
                "field": "registry_orphan",
                "desc": "registry 中有 %s 但 filesystem 无 taxue-%s/SKILL.md" % (name, name)
            })

    # Filesystem 有但 registry 无
    for name in filesystem_names:
        if name == "taxue":
            continue
        if name not in registered_names:
            issues.append({
                "file": name,
                "severity": "warning",
                "field": "registry_missing",
                "desc": "filesystem 有 taxue-%s 但未注册到 skill_registry.json" % name
            })

    return issues


def scan_all_skills():
    """扫描所有 taxue 技能文件"""
    skills = []
    
    # 主入口
    main_file = TAXUE_DIR / "SKILL.md"
    if main_file.exists():
        content = main_file.read_text(encoding="utf-8")
        skills.append({"name": "taxue", "path": main_file, "content": content})
    
    # 子技能
    for d in sorted(SKILLS_DIR.glob("taxue-*")):
        skill_file = d / "SKILL.md"
        if skill_file.exists():
            content = skill_file.read_text(encoding="utf-8")
            skills.append({"name": d.name, "path": skill_file, "content": content})
    
    return skills


def run_quality_gate(verbose=False, repair=False):
    """运行质量门"""
    all_issues = []
    stats = {"scanned": 0, "errors": 0, "warnings": 0, "pass": 0}
    
    skills = scan_all_skills()
    stats["scanned"] = len(skills)
    
    for skill in skills:
        name = skill["name"]
        content = skill["content"]
        metadata = parse_frontmatter(content)
        
        if verbose:
            version = metadata.get("version", "N/A")
            print(f"  [{name}] v{version}")
        
        issues = []
        
        # 1. 版本检查
        issues.extend(check_version(metadata, name))
        
        # 2. 必备章节
        issues.extend(check_required_sections(content, name, REQUIRED_SECTIONS))
        
        # 3. 质量门章节 (v3.5.0 新增)
        issues.extend(check_required_sections(content, name, QUALITY_GATE_SECTIONS))
        
        # 4. 反模式数量
        issues.extend(check_anti_patterns(content, name))
        
        # 5. 输出边界
        issues.extend(check_output_boundary(content, name))
        
        # ------- 新检查：证据硬门遵循 -------
        # 检查是否有数字估算但没有标注来源/假设
        # 这只在子 skill 中检查
        # ------- 新检查：首行描述完整性 -------
        # 检查 description 是否超过 20 字（太短说明描述不足）
        
        for issue in issues:
            issue["skill"] = name
            all_issues.append(issue)
            if issue["severity"] == "error":
                stats["errors"] += 1
            else:
                stats["warnings"] += 1
        
        if not issues:
            stats["pass"] += 1
    
    # ------- 新检查：SKILL_REGISTRY 一致性 -------
    # 注册表中的技能名必须与 filesystem 上的子 skill 目录一一对应
    registry_issues = check_registry_consistency(skills)
    all_issues.extend(registry_issues)
    for issue in registry_issues:
        if issue["severity"] == "error":
            stats["errors"] += 1
        else:
            stats["warnings"] += 1

    return all_issues, stats


def print_report(issues, stats, verbose=False):
    """打印质量报告"""
    print("=" * 60)
    print("taxue 技能体系质量门报告")
    print(f"扫描时间: 2026-07-13")
    print("=" * 60)
    print(f"\n扫描: {stats['scanned']} 个技能")
    print(f"通过: {stats['pass']} 个")
    print(f"错误: {stats['errors']} 个")
    print(f"告警: {stats['warnings']} 个")
    print()
    
    if not issues:
        print("所有检查通过！")
        return 0
    
    # 按严重程度分组
    errors = [i for i in issues if i["severity"] == "error"]
    warnings = [i for i in issues if i["severity"] == "warning"]
    
    if errors:
        print("--- 错误（必须修复）---")
        for e in errors:
            print(f"  [{e['skill']}] {e['desc']}")
        print()
    
    if warnings:
        print("--- 告警（建议修复）---")
        for w in warnings:
            print(f"  [{w['skill']}] {w['desc']}")
        print()
    
    if verbose:
        print("--- 逐技能详情 ---")
        skills = scan_all_skills()
        for skill in skills:
            name = skill["name"]
            content = skill["content"]
            metadata = load_yaml_frontmatter(content)
            version = metadata.get("version", "N/A")
            
            skill_issues = [i for i in issues if i["skill"] == name]
            has = "✓" if not skill_issues else f"✗ ({len(skill_issues)} issues)"
            
            # 检查是否有 Outcome Contract
            has_oc = "✓" if re.search(r"Outcome Contract|产出契约", content) else " "
            has_qg = "✓" if re.search(r"质量门", content) else " "
            
            print(f"  {name:25s} v{version:8s}  OC:{has_oc}  QG:{has_qg}  → {has}")
    
    if stats["errors"] > 0:
        return 2
    if stats["warnings"] > 0:
        return 1
    return 0


def main():
    verbose = "--verbose" in sys.argv
    repair = "--repair" in sys.argv
    
    issues, stats = run_quality_gate(verbose, repair)
    exit_code = print_report(issues, stats, verbose)
    
    print(f"\n总评: {'✓ 全部通过' if exit_code == 0 else '⚠ 有改进空间' if exit_code == 1 else '✗ 需修复'}")
    print(f"质量门版本: v1.0 — 政策版本: v3.5.0")
    
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
