#!/bin/bash
# Taxue适配器设置脚本
# 只读模式：只扫描技能，生成缓存，不修改任何技能文件

set -e

echo "=== Taxue适配器设置 ==="
echo ""

# 1. 检查skill-orchestrator是否存在
SKILL_ORCHESTRATOR="$HOME/.agents/skills/skill-orchestrator"
if [ ! -d "$SKILL_ORCHESTRATOR" ]; then
    echo "错误：skill-orchestrator不存在"
    echo "请先安装skill-orchestrator"
    exit 1
fi

# 2. 生成缓存（只读扫描）
echo "步骤1：扫描所有技能并生成缓存..."
cd "$SKILL_ORCHESTRATOR"
python3 scripts/skill-adapter.py list > /dev/null 2>&1

# 3. 测试适配器
echo ""
echo "步骤2：测试适配器..."
TEST_RESULT=$(python3 scripts/skill-adapter.py search "投资" 2>/dev/null | head -5)
if [ -n "$TEST_RESULT" ]; then
    echo "✓ 适配器测试成功"
else
    echo "✗ 适配器测试失败"
    exit 1
fi

# 4. 测试taxue桥接
echo ""
echo "步骤3：测试taxue桥接..."
TAXUE_BRIDGE="$HOME/.agents/skills/taxue/scripts/taxue-adapter-bridge.py"
if [ -f "$TAXUE_BRIDGE" ]; then
    BRIDGE_RESULT=$(python3 "$TAXUE_BRIDGE" "投资" 2>/dev/null | grep -c "professional_skill")
    if [ "$BRIDGE_RESULT" -gt 0 ]; then
        echo "✓ taxue桥接测试成功"
    else
        echo "✗ taxue桥接测试失败"
    fi
else
    echo "✗ taxue桥接脚本不存在"
fi

# 5. 生成使用说明
echo ""
echo "=== 设置完成 ==="
echo ""
echo "核心特性："
echo "  ✓ 只读模式：不修改任何技能文件"
echo "  ✓ 自动发现：扫描所有已安装技能"
echo "  ✓ 智能匹配：根据问题自动选择最合适的技能"
echo ""
echo "使用方式："
echo "1. 直接使用taxue，它会自动调用适配器"
echo "2. 命令行测试："
echo "   python3 ~/.agents/skills/skill-orchestrator/scripts/skill-adapter.py search \"关键词\""
echo "   python3 ~/.agents/skills/taxue/scripts/taxue-adapter-bridge.py \"问题\""
echo ""
echo "更新技能后："
echo "重新运行此脚本即可更新缓存"
echo ""
echo "原理说明："
echo "  - 适配器只读取SKILL.md，不写入任何文件"
echo "  - 缓存文件：~/.skill-adapter-cache.json"
echo "  - 技能目录完全不受影响"