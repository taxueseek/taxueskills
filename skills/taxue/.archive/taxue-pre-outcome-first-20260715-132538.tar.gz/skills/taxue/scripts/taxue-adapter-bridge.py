#!/usr/bin/env python3
"""
Taxue适配器桥接 - 让taxue智能调用任意技能

用法：
  python3 taxue-adapter-bridge.py "用户问题"
  python3 taxue-adapter-bridge.py --领域投资 "分析茅台"
  python3 taxue-adapter-bridge.py --list-invest
"""
import os
import sys
import json
import argparse
from pathlib import Path

# 添加skill-orchestrator到路径
SKILL_ORCHESTRATOR = Path.home() / ".agents" / "skills" / "skill-orchestrator" / "scripts"
sys.path.insert(0, str(SKILL_ORCHESTRATOR))

# 动态导入SkillAdapter
import importlib.util
spec = importlib.util.spec_from_file_location("skill_adapter", SKILL_ORCHESTRATOR / "skill-adapter.py")
skill_adapter_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(skill_adapter_module)
SkillAdapter = skill_adapter_module.SkillAdapter

def _load_taxue_registry():
    """从 skill_registry.json 加载子技能列表（单点真源）。"""
    reg_path = Path(__file__).resolve().parent.parent / "references" / "skill_registry.json"
    try:
        data = json.loads(reg_path.read_text(encoding="utf-8"))
        skills = data.get("skills", {})
        return {k: v.get("description", k) for k, v in skills.items()}
    except (OSError, json.JSONDecodeError):
        # 回退（不应发生——registry 与 installer 同步创建）
        return {}


class TaxueAdapterBridge:
    def __init__(self, use_cache=True):
        self.adapter = SkillAdapter(use_cache=use_cache)
        self.taxue_subskills = _load_taxue_registry()
        
    def smart_route(self, query: str, context: str = "") -> dict:
        """智能路由：决定用专业技能还是taxue子技能"""
        
        # 1. 搜索专业技能
        professional_skills = self.adapter.search_skills(query)
        
        # 2. 评估专业技能相关性
        if professional_skills and professional_skills[0]['score'] >= 5:
            best_skill = professional_skills[0]
            
            # 检查是否是taxue子技能
            if best_skill['name'].startswith('taxue-'):
                subskill = best_skill['name'].replace('taxue-', '')
                return {
                    'type': 'taxue_subskill',
                    'skill': best_skill['name'],
                    'reason': f"匹配taxue子技能：{self.taxue_subskills.get(subskill, subskill)}",
                    'confidence': best_skill['score'],
                    'call_instruction': f"加载并执行 `{best_skill['name']}` 技能"
                }
            else:
                return {
                    'type': 'professional_skill',
                    'skill': best_skill['name'],
                    'reason': f"发现专业技能：{best_skill['interface'].get('description', '')[:50]}...",
                    'confidence': best_skill['score'],
                    'call_instruction': self.adapter.generate_call_instruction(best_skill['name'], query),
                    'alternatives': [s['name'] for s in professional_skills[1:3]]
                }
        
        # 3. 没有匹配的专业技能，使用taxue默认路由
        return {
            'type': 'taxue_default',
            'skill': 'taxue',
            'reason': "未找到高度匹配的专业技能，使用taxue默认路由",
            'confidence': 0,
            'call_instruction': "使用taxue默认路由流程"
        }
    
    def get_domain_skills(self, domain: str) -> list:
        """获取特定领域的所有技能"""
        return self.adapter.search_skills(domain)
    
    def generate_taxue_integration_code(self) -> str:
        """生成集成到taxue的代码片段"""
        return '''
## 智能技能路由（适配器模式）

在调度之前，先查询是否有更专业的技能：

```python
# 在taxue的调度流程中添加
import subprocess
import json

def query_adapter(query):
    """查询适配器，寻找专业技能"""
    try:
        result = subprocess.run(
            ['python3', '~/.agents/skills/taxue/scripts/taxue-adapter-bridge.py', query],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            return json.loads(result.stdout)
    except:
        pass
    return None

# 在路由判断前调用
adapter_result = query_adapter(user_query)
if adapter_result and adapter_result['type'] == 'professional_skill':
    # 调用专业技能
    print(f"发现专业技能：{adapter_result['skill']}")
    exec(adapter_result['call_instruction'])
else:
    # 使用taxue默认路由
    # ... 原有路由逻辑 ...
```
'''

def main():
    parser = argparse.ArgumentParser(description='Taxue适配器桥接')
    parser.add_argument('query', nargs='?', help='用户查询')
    parser.add_argument('--domain', help='查询特定领域')
    parser.add_argument('--list', help='列出特定领域的技能')
    parser.add_argument('--integration', action='store_true', help='生成集成代码')
    
    args = parser.parse_args()
    
    bridge = TaxueAdapterBridge()
    
    if args.integration:
        print(bridge.generate_taxue_integration_code())
        return
    
    if args.list:
        skills = bridge.get_domain_skills(args.list)
        print(f"\n{args.list}领域的技能：")
        for skill in skills[:10]:
            print(f"  - {skill['name']}: {skill['interface'].get('description', '')[:60]}...")
        return
    
    if args.query:
        result = bridge.smart_route(args.query)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    parser.print_help()

if __name__ == '__main__':
    main()