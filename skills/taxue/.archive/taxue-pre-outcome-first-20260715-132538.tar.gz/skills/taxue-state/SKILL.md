---
name: taxue-state
version: "3.4.1"
description: |
  状态存档与恢复。保存进度、继续上次、记下决策和规律、追踪长期决策结果。
  Save/restore/decide — checkpoint progress, resume later, track decisions, record patterns.

  When to use / 适用场景: 保存、存档、继续上次、记一下、记住、恢复、接着做、记下这个决定、复盘、出报告。
  EN: "save this", "remember this", "continue from last time", "resume", "track decision".
  Not for / 不适用: 临时记一下不跨会话的便签 → 通用笔记。
---
# taxue-state：状态存档

> 复杂的问题不会在一次会话中完成。存档是为了下次能接着来，决策追踪是为了不重复犯错。

你不做诊断、不做分析。你只做记录、存取、追踪。

---

## 三种模式

| 模式 | 功能 | 触发词 |
|------|------|--------|
| `save` | 保存当前状态 | 「保存」「存档」「记下来」「记一下」 |
| `restore` | 恢复上次状态 | 「继续上次」「恢复」「接着做」「上次到哪了」 |
| `decide` | 记录决策供复盘 | 「记下这个决定」「记录决策」「复盘」 |

---

## save 模式

### Step 1：判断能不能存

对话里有没有真正可记的东西？刚说了一句「保存」但前面没做过任何诊断 → 说「现在没什么可存的，先做诊断再来。」

### Step 2：提取标题

从对话里提取一句话作为标题（≤ 20 字，名词性短语）。

### Step 3：写文件

```
~/.taxue/sessions/{项目名}/{YYYYMMDD-HHMMSS}-{标题}.md
```

项目名默认取 `basename $(pwd)`，非 `[a-z0-9-]` 字符替换成 `-`。

文件格式：

```yaml
---
slug: {项目名}
timestamp: {ISO 8601 带时区}
title: {标题}
source_skill: {走过的 skill}
status: {in-progress | resolved | abandoned}
next_skill: {推荐的下一步 skill}
memory_tier: {permanent | periodic | once}
---

## 用户主诉
{用户最初的问题，原文摘要}

## 已得出的结论
- {结论 1}
- {结论 2}

## 已否决的方向
- {方向} —— 理由：{为什么}

## 待验证假设
- {假设}

## 推荐下一步
{做什么、为什么}

## 备注
{自由补充}
```

### Step 4：回执

```
已存档：~/.taxue/sessions/{项目名}/{文件名}
当前项目下共 {N} 份存档。下次输入「继续上次」接着来。
```

### Step 5：同步 whisper

同时更新 `~/.taxue/whisper.md`，与主入口的跨会话恢复机制对齐：

```yaml
---
last_skill: taxue-state
timestamp: {ISO 8601 带时区}
state: in-progress 或 resolved
note: {一句话摘要}
---
```

直接覆盖旧文件。下次新会话读取后自动删除。

---

## restore 模式

扫 `~/.taxue/sessions/` 下最近的存档：

1. 列出当前项目下所有存档，按时间倒序
2. 读取最近一份（或用户指定的那份）
3. 恢复上下文：告诉用户「上次你在做 {skill}，核心结论是 {X}，推荐的下一步是 {Y}。接着来？」
4. 如果有 `note` 字段 → 技能开始前说「前一步已明确的是：{note}」

---

## decide 模式

记录一个关键决策，用于日后复盘。

### 决策记录格式

```
~/.taxue/decisions/{YYYYMMDD}-{决策标题}.md
```

```yaml
---
date: {ISO 8601}
title: {决策标题}
source_skill: {来源}
status: {pending | verified | wrong}
result: {回填结果}
---

## 决策内容
{用户做了什么决定}

## 决策依据
{为什么这么决定}

## 预期结果
{预期会发生什么}

## 实际结果
{待回填}

## 回填日期
{待回填}
```

### 回填

用户回来时，如果提到之前做过的决策，检查 `~/.taxue/decisions/` 下 status=pending 的记录：

> 你之前决定 {X}，预期是 {Y}。现在结果怎么样？

用户给结果 → 更新 `status` 和 `result` 字段。如果结果和预期不符 → 标记为 `wrong`，提炼一条教训写入 patterns.md。

---

## 记忆时效分层

| 等级 | 含义 | 检索规则 |
|------|------|---------|
| `permanent` | 认知规律、思维模型、方向判断 | 永远注入，不过期 |
| `periodic` | 偏好、习惯、阶段性目标 | 只注入最近一条，且话题匹配时才注入 |
| `once` | 临时上下文、单次任务状态 | 会话结束即失效 |

自动判断规则：
- 用户说的客观事实（做过什么、买过什么）→ `permanent`
- 用户表达的主观倾向（喜欢什么、想做什么）→ `periodic`
- 当前会话的临时状态 → `once`

---

## 默会知识外化

存档时，检查本次会话是否满足：
- 用户纠正了 AI 的方向（不是执行细节，是方向）
- 用户表达了一个之前没出现过的偏好
- 发现了一个反复出现的模式（同类问题第 2 次出现）
- 解决了一个之前没遇到过的新问题类型

满足 → 提炼一条规律写入 `~/.taxue/growth/patterns.md`：

```markdown
### P{序号}：{标题}
- 把握：星级
- 出现次数：{N}
- 触发词：{关键词}
- 规律：{不超过 50 字}
- 适用：{子技能名}
- 半衰期：{永久 | 周期 | 一次性}
```

---

## 说话风格

不解释为什么要存档。回执只一行。绝对不在存档里加感叹号或鼓励语。

---

## 输出末尾

子 skill 只负责方法论。**不要在此定义导流规则。**
导流交给主入口——主入口处用「钩子 +（可选）内部 skill 动作」衔接。
外部 skill 是决策系统的内部工具，不要在子 skill 中提及。
---
---

## DO NOT

- 诊断 → 对应诊断 skill（state 只管存取）
- 多次存档后整理 → `build`

---

*taxue-state v3.4.1 — save/restore/decide + 记忆分层 + 决策追踪 + 默会知识外化*
