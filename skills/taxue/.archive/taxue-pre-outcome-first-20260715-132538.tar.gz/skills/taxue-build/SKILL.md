---
name: taxue-build
version: "3.4.1"
description: |
  taxue 系列 skill 工程一体化工具：新建技能、诊断优化已有 skill、升级 skill 到最新版本。All-in-one skill engineering: create new skill, diagnose/optimize existing, upgrade to latest version.

  When to use / 适用场景: 这个问题总是出现、怎么固化流程、固化、工具化、做工具、写skill、经验变工具、重复问题、总是出现、封装、标准化、skill优化、skill诊断、帮我看看这个skill、触发不准确、token消耗、skill太复杂、技能优化、这个skill不生效、升级到最新版本、检查skill更新、更新、版本、taxue升级、有没有新版。
  EN: "turn this into a tool", "standardize this process", "build a system", "optimize skill", "skill diagnosis", "skill not triggering", "debug skill", "reduce token usage", "upgrade taxue", "check for updates", "update skills".
  Not for / 不适用: 不需要新建/诊断/升级skill的场景。
---

# taxue-build：Skill 工程一体化
> 把经验变工具，让工具好用，永不过时。新建、诊断、升级一站式覆盖。

你的任务：完成 taxue 系列 skill 全生命周期管理——把重复经验固化成新技能，诊断优化已有技能，升级到最新版本。

---

## 核心功能

### 1. Build：新建技能（重复三次的问题就该封装）
触发条件：用户需要固化重复流程，新建工具/skill时。
三个前提：
1. 问题会反复出现——只做一次的事不需要技能化
2. 解法可以标准化——创意部分不能，但判断标准可以
3. 标准化后比临场判断更好——在慌乱中，预设规则比现场的你要可靠

六步标准：
1. 明确要解决什么问题、触发条件、输出内容
2. 设计目的、标准、边界、界面、验收、迭代规则
3. 生成SKILL.md，保留触发词和description
4. 测试：用真实场景验证触发率和输出可用率
5. 输出：「做好了。怎么用：[触发词和场景]。测一下？」
6. 可选：教用户方法论（仅当用户主动要求时）

### 2. Skill：诊断优化已有技能
触发条件：用户反馈skill触发不准、token太重、逻辑太乱、效果差时。
六种改造模式：
| 模式 | 触发 | 做什么 |
|------|------|--------|
| 诊断 | 「帮我看看这个skill」 | 分析问题，不改 |
| 优化 | 「token消耗太大」 | 减少冗余，提升效率 |
| 触发优化 | 「skill触发不准确」 | 重写 description 和触发词 |
| 边界优化 | 「skill做了不该做的事」 | 收窄边界，明确边界 |
| 评估 | 「帮我评估这个skill」 | 生成测试用例→执行→度量→改进 |
| 重构 | 「skill太复杂」 | 拆分/合并/简化 |

六项诊断维度：
1. 触发率：description 是否覆盖足够多的触发场景？
2. 边界清晰度：边界声明是否明确？
3. token 效率：有没有冗余内容？
4. 路由完整性：下游协作是否覆盖？
5. 上下文效率：有没有可以按需加载而非预加载的内容？超过 150 行的 SKILL.md，考虑把部分内容移到 references/ 里，用到的时候才读。
6. 流程清晰度：步骤是否可执行？

优化原则：
- 触发词要具体：不是「帮我」，是「帮我拆一下」「帮我看看这个skill」
- 边界要明确：什么不做，比什么做更重要
- token 要精简：每个字都要有存在的理由
- 流程要可执行：步骤要具体，不要抽象

评估标准：路由准确率>90%，输出可用率>80%

### 3. Upgrade：版本升级
触发条件：用户需要升级taxue系列skill到最新版本时。
核心流程：
1. 扫描本地~/.agents/skills/目录下所有taxue系列skill版本
2. 对比远程最新版本，列出可升级清单
3. 用户选择升级全部或指定skill
4. 执行升级：备份当前版本→下载新版本→验证→完成
特殊处理：本地版本高于远程时，询问是否覆盖本地修改

---

## 输出末尾

子 skill 只负责方法论。**不要在此定义导流规则。**
导流交给主入口——主入口处用「钩子 +（可选）内部 skill 动作」衔接。
外部 skill 是决策系统的内部工具，不要在子 skill 中提及。
---
---

## Outcome Contract

- **产出**：一个可复用的工具/流程/文件
- **做完的标准**：用户能直接使用这个工具，不需要再修改
- **不做的事**：不做问题消解（去 solve）

## 输出前质量门（强制自查）

提交前过一遍：

1. 用户能直接使用吗？
2. 有使用说明吗？
3. 可复用吗？

任一不通过，修正后再输出。

---

## DO NOT

- 不需要新建/优化/升级skill的场景 → 直接处理需求
- 非taxue系列skill的升级 → 手动编辑

---

*taxue-build v3.4.1 — 新建+诊断+升级一体化，合并原taxue-skill、taxue-upgrade功能 · 产出契约 · 质量门*